# WanderAffiliate

A ready-to-run React + Vite + Tailwind project. 

Quick start:

```bash
npm install
npm run dev
```

Replace affiliate links with your own tracking URLs.
