import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

export default function Home() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email && message) {
      console.log("Message sent:", { email, message });
      setSubmitted(true);
      setEmail("");
      setMessage("");
    }
  };

  return (
    <div className="bg-gray-50 font-sans overflow-hidden">
      {/* Hero */}
      <div className="relative h-screen flex items-center justify-center text-center">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
        >
          <source src="https://cdn.coverr.co/videos/coverr-tropical-paradise-1555/1080p.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-black/60"></div>
        <div className="relative z-10 text-white px-6 max-w-3xl">
          <motion.h1
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="text-5xl md:text-7xl font-extrabold drop-shadow-lg mb-6"
          >
            WanderAffiliate 🌍
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 1 }}
            className="text-lg md:text-2xl text-gray-200 mb-8"
          >
            Discover breathtaking destinations, read inspiring stories, and book smarter.
          </motion.p>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            <Link
              to="/destinations"
              className="px-8 py-4 bg-gradient-to-r from-pink-500 to-red-500 rounded-full font-bold text-white shadow-xl hover:scale-105 transition"
            >
              ✈️ Explore Now
            </Link>
          </motion.div>
        </div>
      </div>

      {/* Main options */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-24 text-center">
        <h2 className="text-4xl font-extrabold mb-16 bg-gradient-to-r from-indigo-500 to-purple-600 bg-clip-text text-transparent">
          Start Your Journey
        </h2>

        <div className="grid gap-10 md:grid-cols-3">
          {[
            {
              to: "/destinations",
              title: "🌎 Explore Destinations",
              desc: "Find the most popular and unique places around the world.",
              gradient: "from-indigo-500 to-purple-600",
            },
            {
              to: "/blog",
              title: "📝 Travel Blog",
              desc: "Read travel tips, guides, and inspiring stories.",
              gradient: "from-green-500 to-emerald-600",
            },
            {
              to: "#contact",
              title: "📩 Contact Us",
              desc: "Get in touch with us for any inquiries or collaborations.",
              gradient: "from-pink-500 to-red-600",
            },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.2 }}
            >
              <Link
                to={item.to}
                className={`p-10 bg-gradient-to-r ${item.gradient} text-white rounded-3xl shadow-2xl hover:scale-105 transition transform block`}
              >
                <span className="text-2xl font-bold mb-3 block">{item.title}</span>
                <p className="text-sm text-gray-100">{item.desc}</p>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Contact section */}
      <div id="contact" className="relative py-24 bg-gradient-to-r from-indigo-50 to-purple-50">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <motion.h2
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-3xl font-extrabold mb-6"
          >
            Get in Touch ✉️
          </motion.h2>
          {submitted ? (
            <p className="text-green-600 font-medium text-center">
              ✅ Message sent! We’ll reply soon.
            </p>
          ) : (
            <motion.form
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              onSubmit={handleSubmit}
              className="space-y-6 bg-white/70 backdrop-blur-xl p-10 rounded-3xl shadow-2xl"
            >
              <input
                type="email"
                placeholder="Your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
              />
              <textarea
                placeholder="Your message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm h-32 focus:ring-2 focus:ring-indigo-500 outline-none"
              />
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 rounded-lg font-semibold hover:opacity-90 transition"
              >
                Send Message
              </button>
            </motion.form>
          )}
        </div>
      </div>
    </div>
  );
}
